# TaskFlow 🗂️

Gestor de tareas compartido y en tiempo real — construido con HTML puro + Supabase.

---

## ⚡ Configuración en 5 pasos

### Paso 1 — Crear proyecto en Supabase

1. Ve a [supabase.com](https://supabase.com) e inicia sesión (es gratis)
2. Clic en **"New project"**
3. Ponle un nombre (ej: `taskflow`), elige una región cercana y crea una contraseña
4. Espera ~1 minuto mientras se inicializa el proyecto

---

### Paso 2 — Crear las tablas

1. En tu proyecto de Supabase, ve a **SQL Editor** → **New query**
2. Copia y pega todo el contenido del archivo `schema.sql`
3. Clic en **Run** (▶)
4. Verifica que aparezca "Success" sin errores

---

### Paso 3 — Obtener las credenciales

1. En Supabase, ve a **Settings** → **API**
2. Copia los dos valores:
   - **Project URL** → algo como `https://abcdefghij.supabase.co`
   - **anon public key** → un token largo

---

### Paso 4 — Configurar el archivo `index.html`

Abre `index.html` con cualquier editor de texto y busca estas dos líneas cerca del inicio:

```javascript
const SUPABASE_URL = 'REEMPLAZA_CON_TU_PROJECT_URL';
const SUPABASE_KEY = 'REEMPLAZA_CON_TU_ANON_KEY';
```

Reemplaza los valores con los del paso anterior:

```javascript
const SUPABASE_URL = 'https://tuproyecto.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6...';
```

Guarda el archivo.

---

### Paso 5 — Publicar en GitHub Pages

1. Crea un repositorio nuevo en GitHub (puede ser privado o público)
2. Sube el archivo `index.html` al repositorio
3. Ve a **Settings** → **Pages**
4. En "Branch", selecciona `main` y carpeta `/ (root)`
5. Clic en **Save**
6. En 1-2 minutos tendrás una URL pública como:
   `https://tu-usuario.github.io/tu-repositorio/`

**¡Comparte esa URL con tu equipo y todos verán los mismos datos en tiempo real!**

---

## 👥 Funcionalidades

| Función | Admin | Usuario |
|---|---|---|
| Ver todas las tareas | ✅ | ✅ |
| Ver mis tareas | ✅ | ✅ |
| Reportar avances | ✅ | ✅ (si está asignado) |
| Comentar tareas | ✅ | ✅ |
| Crear tareas | ✅ | ❌ |
| Editar tareas | ✅ | ✅ (si está asignado) |
| Eliminar tareas | ✅ | ❌ |
| Crear usuarios | ✅ | ❌ |
| Eliminar usuarios | ✅ | ❌ |
| Ver reportes | ✅ | ✅ |

---

## 🔄 Tiempo real

Cualquier cambio que haga un usuario (nuevo comentario, avance, tarea nueva) aparece automáticamente en las pantallas de todos los demás sin necesidad de recargar la página.

---

## ➕ Agregar más usuarios

El administrador puede crear nuevos usuarios desde la sección **"Usuarios"** en el panel de administración. También puedes agregarlos directamente desde **Supabase → Table Editor → tf_users**.

---

## 🗄️ Estructura de la base de datos

| Tabla | Descripción |
|---|---|
| `tf_users` | Usuarios del sistema |
| `tf_tasks` | Tareas con estado, prioridad, etapas |
| `tf_progress` | Historial de avances por tarea |
| `tf_comments` | Comentarios por tarea |

---

## 🔒 Nota de seguridad

Esta configuración usa RLS (Row Level Security) con acceso público para facilitar el uso en equipo interno sin autenticación. Si necesitas control de acceso más estricto (login con contraseña), se puede agregar autenticación de Supabase Auth.
