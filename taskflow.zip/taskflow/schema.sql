-- =============================================
-- TaskFlow - Schema para Supabase
-- Ejecutar en: Supabase > SQL Editor > New query
-- =============================================

-- Tabla de usuarios
create table if not exists tf_users (
  id text primary key,
  name text not null,
  email text unique not null,
  role text not null default 'user', -- 'admin' | 'user'
  initials text not null,
  color text not null default 'av-user',
  created_at timestamptz default now()
);

-- Tabla de tareas
create table if not exists tf_tasks (
  id text primary key,
  title text not null,
  description text default '',
  status text not null default 'Pendiente',
  priority text not null default 'Media',
  stage integer not null default 0,
  progress integer not null default 0,
  due_date text default '—',
  created_by text references tf_users(id),
  assignees text[] default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Tabla de avances
create table if not exists tf_progress (
  id bigserial primary key,
  task_id text references tf_tasks(id) on delete cascade,
  user_id text references tf_users(id),
  text text not null,
  pct integer not null default 0,
  created_at timestamptz default now()
);

-- Tabla de comentarios
create table if not exists tf_comments (
  id bigserial primary key,
  task_id text references tf_tasks(id) on delete cascade,
  user_id text references tf_users(id),
  text text not null,
  created_at timestamptz default now()
);

-- =============================================
-- Habilitar Realtime para actualizaciones en vivo
-- =============================================
alter publication supabase_realtime add table tf_tasks;
alter publication supabase_realtime add table tf_progress;
alter publication supabase_realtime add table tf_comments;

-- =============================================
-- Datos iniciales
-- =============================================
insert into tf_users (id, name, email, role, initials, color) values
  ('admin', 'Administrador', 'admin@taskflow.com', 'admin', 'AD', 'av-admin')
on conflict (id) do nothing;

-- =============================================
-- Row Level Security (RLS) - acceso público de lectura/escritura
-- (para uso interno de equipo sin auth de Supabase)
-- =============================================
alter table tf_users enable row level security;
alter table tf_tasks enable row level security;
alter table tf_progress enable row level security;
alter table tf_comments enable row level security;

create policy "public_all" on tf_users for all using (true) with check (true);
create policy "public_all" on tf_tasks for all using (true) with check (true);
create policy "public_all" on tf_progress for all using (true) with check (true);
create policy "public_all" on tf_comments for all using (true) with check (true);
